import spacy
import neuralcoref
nlp_en = en_core_coref_md.load()

input = open('./input/another_try.txt', 'r').read()
doc = nlp_en(input)
for sent in doc.sents:
        for i, word in enumerate(sent):
              if word.head == word:
                 head_idx = 0
              else:
                 head_idx = word.head.i - sent[0].i + 1
              output = open('coref_output.txt', 'a')
              output.write("%d\t%s\t%s\t%s\t%s\t%s\t%s\n"%(
                 i+1, # There's a word.i attr that's position in *doc*
                  word,
                  word.lemma_,
                  word.tag_, # Fine-grained tag
                  word.ent_type_,
                  str(head_idx),
                  word.dep_ # Relation
                  
                 ))