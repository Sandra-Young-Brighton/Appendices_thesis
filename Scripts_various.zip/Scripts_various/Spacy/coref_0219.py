import spacy
import neuralcoref
import en_coref_md
import os

nlp_en = en_coref_md.load()
path = './input_zenodo/'
filelist = os.listdir(path)

for file in filelist:
#     try:
#         input = open(path+file, 'r').read()
#         doc = nlp_en(input)
#         fileout = open('corefclusters_jeff0219.txt', 'a')
#         fileout.write(file+': Coref clusters\n')
#         fileout.write(str(doc._.has_coref))
#         fileout.write('\n')
#         fileout.write(str(doc._.coref_clusters))
#         fileout.write('\n')
#     except:
#         print('An error occurred')
    try:
        file = open(path+file).read()
        #nlp = spacy.load('en_coref_md')
        doc = nlp_en(file)
        tokens = [t.text for t in doc]
        is_pronoun = 'it'
            
        #print(doc._.has_coref)
        coref_clusters = doc._.coref_clusters
        print(coref_clusters)
    except MemoryError:
        print('MemoryError:'+file+'\n')  
              
    for token in doc:
        if token.text == is_pronoun:
                print(token._.in_coref)
                print(token._.coref_clusters)