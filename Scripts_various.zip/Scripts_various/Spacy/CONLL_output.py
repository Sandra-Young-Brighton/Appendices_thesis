import spacy
import en_core_web_sm
import os
from twisted.python import filepath

nlp_en = en_core_web_sm.load()

path = './input'
#def list_dir_fullpath(d):
 #   return [os.path.join(d,f) for f in os.listdir(d)]

filelist = [os.path.join(path,f) for f in os.listdir(path)]
for file in filelist:
    input = open(file, 'rU').read()

    input = input.rsplit()
    input = " ".join(input)

# def remove_whitespace_entities(doc):
#     doc.ents = [e for e in doc.ents if not e.text.isspace()]
#     return doc
# 
# nlp_en.add_pipe(remove_whitespace_entities, after='ner')
# 
# print(nlp_en.pipeline)

    doc = nlp_en(input)
    no_path = os.path.basename(file)
    filename = os.path.splitext(no_path)
    (f, ext) = filename
    for sent in doc.sents:
        for i, word in enumerate(sent):
            if word.head == word:
                head_idx = 0
            else:
                head_idx = word.head.i - sent[0].i + 1
            output = open('./output/CONLL_'+f+'.txt', 'a')
            output.write("%d\t%s\t%s\t%s\t%s\t%s\t%s\n"%(
                i+1, # There's a word.i attr that's position in *doc*
                word,
                word.lemma_,
                word.tag_, # Fine-grained tag
                word.ent_type_,
                str(head_idx),
                word.dep_ # Relation
                ))