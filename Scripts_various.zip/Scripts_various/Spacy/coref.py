import spacy
import neuralcoref
import en_coref_md
import os

nlp_en = en_coref_md.load()
path = './input_zenodo/'
filelist = os.listdir(path)

for file in filelist:
    try:
        input = open(path+file, 'r').read()
        doc = nlp_en(input)
        fileout = open('corefclusters_zenodo.txt', 'a')
        fileout.write(file+': Coref clusters\n')
        fileout.write(str(doc._.has_coref))
        fileout.write('\n')
        fileout.write(str(doc._.coref_clusters))
        fileout.write('\n')
    except:
        print('An error occurred')
# doc._.coref_clusters[1].mentions
# doc._.coref_clusters[1].mentions[-1]
# doc._.coref_clusters[1].mentions[-1]._.coref_cluster.main
# 
# token = doc[-1]
# token._.in_coref
# token._.coref_clusters
# 
# span = doc[-1:]
# span._.is_coref
# span._.coref_cluster.main
# span._.coref_cluster.main._.coref_cluster